import './App.css';
import Todo1 from './Components/Todo1';

function App() {
  return (
    <div className="App">
        <Todo1 />
    </div>
  );
}

export default App;
